#include <stdio.h>

int main(void) {
	printf("Hello, World in C!\n");
	return 0;
}
